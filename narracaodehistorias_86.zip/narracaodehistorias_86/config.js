export const firebaseConfig = {
  apiKey: "AIzaSyA-M-jIVr3mCmH3v_75exyO94dfm0eYDPM",
  authDomain: "narrador-historias-f9f09.firebaseapp.com",
  databaseURL: "https://narrador-historias-f9f09-default-rtdb.firebaseio.com",
  projectId: "narrador-historias-f9f09",
  storageBucket: "narrador-historias-f9f09.appspot.com",
  messagingSenderId: "273634895541",
  appId: "1:273634895541:web:d1ddcf86f0cd02010680fc"
};
